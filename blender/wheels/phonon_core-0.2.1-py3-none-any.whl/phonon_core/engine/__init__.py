"""phonon_core.engine — vendored A2 subset (pure-numpy D(q)).

The phonopy-backed A1 engine (`dq_phonopy`) is DELIBERATELY ABSENT from this
wheel: phonopy cannot be a dependency inside Blender, and a module that can
never import is worse than one that does not exist. Use `load_engine_np` —
the A2 engine, oracle-validated against A1 at build time in the core tree
(phonon-core 0.6.86, tests/test_engine_dq_numpy.py).
"""
from .dq_numpy import load_engine_np, evaluate_dq_np, evaluate_dq_np_batch

__all__ = ["load_engine_np", "evaluate_dq_np", "evaluate_dq_np_batch"]
